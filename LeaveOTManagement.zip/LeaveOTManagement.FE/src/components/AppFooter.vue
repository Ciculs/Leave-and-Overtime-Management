<template>
  <footer class="footer">
    <p>© 2026 LeaveOT System. All rights reserved.</p>
  </footer>
</template>

<style scoped>
.footer {
  padding: 20px 0;
  text-align: center;
  color: #707eae;
  font-size: 14px;
}
</style>