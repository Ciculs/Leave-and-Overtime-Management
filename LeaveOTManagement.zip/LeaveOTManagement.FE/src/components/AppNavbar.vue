<template>
  <div class="navbar">
    <div class="logo">Leave & OT System</div>
    <div class="user">
      <span>👤 Admin</span>
    </div>
  </div>
</template>

<style scoped>
.navbar {
  height: 60px;
  background: #2c3e50;
  color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 25px;
}

.logo {
  font-weight: bold;
  font-size: 18px;
}

.user {
  font-size: 14px;
}
</style>