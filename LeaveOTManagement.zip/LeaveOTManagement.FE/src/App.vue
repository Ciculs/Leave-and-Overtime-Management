<template>
  <router-view />
</template>

<style>
/* Reset global để không bị hở mép */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  font-family: 'Inter', sans-serif;
  background-color: #f4f7fe;
}
</style>